
import { redirect } from "next/navigation"

export default function WatchlistRedirect() {
    redirect("/profile/my-watchlist")
}
